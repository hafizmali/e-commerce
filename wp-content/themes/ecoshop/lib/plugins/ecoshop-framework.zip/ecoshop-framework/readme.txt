=== Vafpress Framework Plugin ===
Contributors: vafpress
Donate link: http://vafpress.com/vafpress-framework
Tags: option, metabox, and shortocode generator framework
Requires at least: 3.3
Tested up to: 3.6.0
Stable tag: 2.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Vafpress Framework Plugin

== Description ==

Plugin version of Vafpress Framework (http://vafpress.com/vafpress-framework)

== Installation ==

1. Upload plugin package file to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Why is this page blank? =

No one asked anything yet :p

== Screenshots ==

None

== Changelog ==

= 2.0 =
* Initial Upload

== Upgrade Notice ==

None